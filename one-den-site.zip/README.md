# ONE DEN

Outerwear for people and dogs. Designed in Bowmanville, Ontario.

Plain static site: one `index.html`, product photos in `img/`. No build step, no dependencies.

## Put it on GitHub

1. Create a new empty repo on github.com (for example `one-den`).
2. Unzip this folder, then in a terminal inside it run:

```
git init
git add .
git commit -m "ONE DEN site"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/one-den.git
git push -u origin main
```

Or skip the terminal: on the empty repo page click "uploading an existing file" and drag in everything from this folder.

## Host it on Vercel

1. Go to vercel.com, sign in with GitHub, click **Add New > Project**.
2. Import the `one-den` repo.
3. Framework preset: **Other**. Leave build command and output directory empty.
4. Click **Deploy**.

Every push to `main` redeploys automatically. Add a custom domain under Project > Settings > Domains.

## Editing

* Copy and products: `index.html`
* Colours and fonts: the `:root` block at the top of the `<style>` tag
* Photos: swap files in `img/` keeping the same names
